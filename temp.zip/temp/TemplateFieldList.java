package com.nm.esign.entities;


public class TemplateFieldList {


    private boolean isSelected;
    private String templateId;
    private String templateName;
    private  String templateDesc;

    private String templateType;
    private String templateCreationDate;
    private  String templateLastUpdateDate;
    private  String companyId;

    private String allfields_TagId;
    private String allfields_documentPageNumber;
    private String allfields_coordinateXRatio;
    private String allfields_coordinateYRatio;
    private String allfields_elementWidthRatio;
    private String allfields_elementHeightRatio;
    private String allfields_tabOrder;
    private String allfields_partyResponsible;
    private String templateCreatedByName;
    private String allfields_fieldType;

    public String getAllfields_fieldType() {
        return allfields_fieldType;
    }

    public void setAllfields_fieldType(String allfields_fieldType) {
        this.allfields_fieldType = allfields_fieldType;
    }

    public String getTemplateCreatedByName() {
        return templateCreatedByName;
    }

    public void setTemplateCreatedByName(String templateCreatedByName) {
        this.templateCreatedByName = templateCreatedByName;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getTemplateDesc() {
        return templateDesc;
    }

    public void setTemplateDesc(String templateDesc) {
        this.templateDesc = templateDesc;
    }

    public String getTemplateType() {
        return templateType;
    }

    public void setTemplateType(String templateType) {
        this.templateType = templateType;
    }

    public String getTemplateCreationDate() {
        return templateCreationDate;
    }

    public void setTemplateCreationDate(String templateCreationDate) {
        this.templateCreationDate = templateCreationDate;
    }

    public String getTemplateLastUpdateDate() {
        return templateLastUpdateDate;
    }

    public void setTemplateLastUpdateDate(String templateLastUpdateDate) {
        this.templateLastUpdateDate = templateLastUpdateDate;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getAllfields_TagId() {
        return allfields_TagId;
    }

    public void setAllfields_TagId(String allfields_TagId) {
        this.allfields_TagId = allfields_TagId;
    }

    public String getAllfields_documentPageNumber() {
        return allfields_documentPageNumber;
    }

    public void setAllfields_documentPageNumber(String allfields_documentPageNumber) {
        this.allfields_documentPageNumber = allfields_documentPageNumber;
    }

    public String getAllfields_coordinateXRatio() {
        return allfields_coordinateXRatio;
    }

    public void setAllfields_coordinateXRatio(String allfields_coordinateXRatio) {
        this.allfields_coordinateXRatio = allfields_coordinateXRatio;
    }

    public String getAllfields_coordinateYRatio() {
        return allfields_coordinateYRatio;
    }

    public void setAllfields_coordinateYRatio(String allfields_coordinateYRatio) {
        this.allfields_coordinateYRatio = allfields_coordinateYRatio;
    }

    public String getAllfields_elementWidthRatio() {
        return allfields_elementWidthRatio;
    }

    public void setAllfields_elementWidthRatio(String allfields_elementWidthRatio) {
        this.allfields_elementWidthRatio = allfields_elementWidthRatio;
    }

    public String getAllfields_elementHeightRatio() {
        return allfields_elementHeightRatio;
    }

    public void setAllfields_elementHeightRatio(String allfields_elementHeightRatio) {
        this.allfields_elementHeightRatio = allfields_elementHeightRatio;
    }

    public String getAllfields_tabOrder() {
        return allfields_tabOrder;
    }

    public void setAllfields_tabOrder(String allfields_tabOrder) {
        this.allfields_tabOrder = allfields_tabOrder;
    }

    public String getAllfields_partyResponsible() {
        return allfields_partyResponsible;
    }

    public void setAllfields_partyResponsible(String allfields_partyResponsible) {
        this.allfields_partyResponsible = allfields_partyResponsible;
    }
}
