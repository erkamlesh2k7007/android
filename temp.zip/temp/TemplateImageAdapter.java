package com.nm.esign.adapter;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AbsoluteLayout;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.nm.esign.R;
import com.nm.esign.activity.ViewTemplate;
import com.nm.esign.entities.Entities;
import com.nm.esign.entities.TemplateFieldList;
import com.nm.esign.entities.ZoomLayout;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by Gunaseelan on 11-12-2015.
 * Simple adapter class, used for show all documentLists in list
 */
public class TemplateImageAdapter extends RecyclerView.Adapter<TemplateImageAdapter.ViewHolder> /* implements View.OnTouchListener*/{

   // ArrayList<TemplateFieldList> templateLists;

    TreeMap<Integer, ArrayList<TemplateFieldList> > myMap;

    AbsoluteLayout ll;
    LinearLayout.LayoutParams param;
    int height_data=0;
    int width_data=0;
    private Context mContext;
    private Integer[] mKeys;
    String templateName;
    int key;
    AbsoluteLayout.LayoutParams paramData;

    Entities entities=new Entities();
    Entities.Communicator communicator=entities.new Communicator();
    Entities.Server server=entities.new Server();
    String coordinateXRatio="",coordinateYRatio="",elementWidthRatio="",elementHeightRatio="",fieldType="";

/*
    *//*-------------------------------------------*//*
    private static final String TAG1 = "Touch";
    @SuppressWarnings("unused")
    private static final float MIN_ZOOM = 1f, MAX_ZOOM = 1f;

    Matrix matrix = new Matrix();
    Matrix savedMatrix = new Matrix();

    // The 3 states (events) which the user is trying to perform
    static final int NONE = 0;
    static final int DRAG = 1;
    static final int ZOOM = 2;
    int mode = NONE;

    // these PointF objects are used to record the point(s) the user is touching
    PointF start = new PointF();
    PointF mid = new PointF();
    float oldDist = 1f;
    *//*-------------------------------------------*/

    public TemplateImageAdapter(Context ctx, TreeMap<Integer, ArrayList<TemplateFieldList>> myMapData ) {
       // this.templateLists = new ArrayList<>(templateLists);
       // this.myMap= new HashMap<String, ArrayList<TemplateFieldList>>();
        this.myMap=myMapData;
        mKeys= myMap.keySet().toArray(new Integer[myMapData.size()]);
        //mKeys = myMap.keySet().toArray(new String[myMapData.size()]);
        mContext = ctx;

    }



    /* @Override
     public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
         View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.document_list_item, parent, false);
         return new ViewHolder(v);
     }
 */
    @Override
    public TemplateImageAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.gallery_thumbnail, parent, false);


        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.bindData(myMap.get(position));
        final int keytemp = mKeys[position];
        ll.setVisibility(View.INVISIBLE);
        ll.setVisibility(View.GONE);

     // keytemp=Integer.parseInt(key);
        key=keytemp;
        int pageNumber=1;
        String access_token=ViewTemplate.access_tokenTemp;

       // String img_url="https://www.esigngenie.com/wp-content/uploads/2015/12/hand_transparant.jpg?id=1364" ;

        try {
            communicator.urls = new URL(server.url + "/templates/getpageimage?templateId="+ViewTemplate.templateIdTemp+ "&pageNumber=" +(position+1)+ "&access_token=" +access_token );
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        String img_url=  ""+communicator.urls;
         System.out.println("img_url=="+img_url);
      /*  Glide.with(mContext).load(R.drawable.register_injury)*/
        Glide.with(mContext).load(img_url)
                .thumbnail(0.5f)
                .crossFade()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.thumbnail);


        /*TouchImageViewgeView img = new TouchImageView(this);
        img.setImageResource(R.drawable.ice_age_2);
        img.setMaxZoom(4f);

        setContentView(img);*/
        holder.documentName.setText("document name");


        if(myMap.get(key).size()>0) {
            System.out.println("key with data=="+key);

       ViewTreeObserver observer = ll.getViewTreeObserver();

        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

            @Override
            public void onGlobalLayout() {
                // TODO Auto-generated method stub
                init();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    ll.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                } else {
                    //noinspection deprecation
                    ll.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                }
              //  ll.getViewTreeObserver().removeGlobalOnLayoutListener(this);

                System.out.println("height="+height_data);
                System.out.println("width="+width_data);
              //  myMap.get("1").get(0).getAllfields_coordinateXRatio()
               /* String coordinateXRatio="",coordinateYRatio="",elementWidthRatio="",elementHeightRatio="",fieldType="";*/
                coordinateXRatio=""; coordinateYRatio=""; elementWidthRatio=""; elementHeightRatio=""; fieldType="";



               for(int i=0;i<myMap.get(key).size();i++) {

                   ll.setVisibility(View.VISIBLE);
                       coordinateXRatio = myMap.get(key).get(i).getAllfields_coordinateXRatio();
                       coordinateYRatio = myMap.get(key).get(i).getAllfields_coordinateYRatio();
                       elementWidthRatio = myMap.get(key).get(i).getAllfields_elementWidthRatio();
                       elementHeightRatio = myMap.get(key).get(i).getAllfields_elementHeightRatio();
                       fieldType = myMap.get(key).get(i).getAllfields_fieldType();

                       System.out.println("coordinateXRatio=" + coordinateXRatio);
                       System.out.println("coordinateYRatio=" + coordinateYRatio);
                       System.out.println("elementHeightRatio=" + elementHeightRatio);
                       System.out.println("fieldType=" + fieldType);
                       getParameter(coordinateXRatio, coordinateYRatio, elementWidthRatio, elementHeightRatio, fieldType, i);
                   coordinateXRatio = "";
                   coordinateYRatio = "";
                   elementWidthRatio ="";
                   elementHeightRatio = "";
                   fieldType = "";
                   }

        }


        });
        }


        ll.setVisibility(View.INVISIBLE);
       // ll.setVisibility(View.GONE);
    }



    public void getParameter(String coordinateXRatio,String coordinateYRatio,String elementWidthRatio,String elementHeightRatio,String fieldType,int i) {




        int left = (int) (width_data * Double.parseDouble(coordinateXRatio));
        int top = (int) (height_data * Double.parseDouble(coordinateYRatio));
        int widthData=(int) (width_data * Double.parseDouble(elementWidthRatio));
        int heightData=(int) (height_data * Double.parseDouble(elementHeightRatio));
         paramData = new AbsoluteLayout.LayoutParams(widthData, heightData, left, top);
         Calendar calendar;
        int year, month, day;
       // LinearLayout.LayoutParams params = new TableLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
      if(fieldType.trim().equals("textfield") ) {
          EditText et = new EditText(mContext.getApplicationContext());

          et.setLayoutParams(paramData);
          et.setTextSize(6);
          et.setPadding(0, 0, 0, 0);
          //et.setText("Dynamic EditText!");
          et.setBackgroundColor(Color.parseColor("#c7ecfc"));
          ll.addView(et);
      } else if(fieldType.trim().equals("checkboxfield")) {
          CheckBox cb = new CheckBox(mContext.getApplicationContext());

          cb.setLayoutParams(paramData);
          cb.setTextSize(6);
          cb.setPadding(0, 0, 0, 0);
         // cb.setText("ckb");
          cb.setBackgroundColor(Color.parseColor("#c7ecfc"));
          ll.addView(cb);
      } else if(fieldType.trim().equals("initialfield") ) {

          EditText et = new EditText(mContext.getApplicationContext());

          /*InputMethodManager imm = (InputMethodManager)mContext. getSystemService(Context.INPUT_METHOD_SERVICE);
          imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);*/

          et.setLayoutParams(paramData);
          et.setTextSize(6);
          et.setPadding(0, 0, 0, 0);
          //et.setText("Dynamic EditText!");
          et.setBackgroundColor(Color.parseColor("#c7ecfc"));
          ll.addView(et);




      }  else if(fieldType.trim().equals("securedfield") ) {
          TextView et = new TextView(mContext.getApplicationContext());

          et.setLayoutParams(paramData);
          et.setTextSize(6);
          et.setPadding(0, 0, 0, 0);
         // et.setText("Dynamic EditText!");
          et.setBackgroundColor(Color.parseColor("#c7ecfc"));
          ll.addView(et);

      } else if(fieldType.trim().equals("signfield") ) {
          CheckBox et = new CheckBox(mContext.getApplicationContext());

          et.setLayoutParams(paramData);
          et.setTextSize(6);
          et.setPadding(0, 0, 0, 0);
         // et.setText("Dynamic EditText!");
          et.setBackgroundColor(Color.parseColor("#c7ecfc"));
          ll.addView(et);

      } else if(fieldType.trim().equals("datefield")) {
          DatePicker et = new DatePicker(mContext.getApplicationContext());

          calendar = Calendar.getInstance();
          year = calendar.get(Calendar.YEAR);
          month = calendar.get(Calendar.MONTH);
          day = calendar.get(Calendar.DAY_OF_MONTH);
          et.init(year, month, day, null);

          et.setLayoutParams(paramData);
          et.setPadding(0, 0, 0, 0);
        //  et.setText("Dynamic EditText!");
         // et.setBackgroundColor(Color.parseColor("#c7ecfc"));
          ll.addView(et);
      }
        else {
          EditText et = new EditText(mContext.getApplicationContext());



          et.setLayoutParams(paramData);
          et.setTextSize(6);
          et.setPadding(0, 0, 0, 0);
          //et.setText("Dynamic EditText!");
          et.setBackgroundColor(Color.parseColor("#c7ecfc"));
          ll.addView(et);

      }

    }

    public void init() {
        height_data= ll.getHeight();
        width_data = ll.getWidth();
    }

    @Override
    public int getItemCount() {
        return myMap.size();
    }



    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public  class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public ImageView thumbnail;
        public TextView documentName;

        LinearLayout fl_zoom_adapter;


        public ViewHolder(View v) {
            super(v);
            ll=(AbsoluteLayout)v.findViewById(R.id.ll_image_tempplate) ;
            ll.setVisibility(View.INVISIBLE);
            ll.setVisibility(View.GONE);
            thumbnail = (ImageView) v.findViewById(R.id.thumbnail);
            documentName=(TextView)v.findViewById(R.id.txt_img_document_name_item);
            fl_zoom_adapter=(LinearLayout)v.findViewById(R.id.fl_zoom_adapter);
            ViewTemplate  activity = (ViewTemplate) mContext;
            ZoomLayout myZoomView = new ZoomLayout(activity);
           // fl_zoom_adapter.addView(myZoomView);



        }


        public void bindData( ArrayList<TemplateFieldList> templateLists) {
            ll.setVisibility(View.INVISIBLE);

        }
    }
}