package com.nm.esign.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.app.ProgressDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;


import org.json.JSONArray;
import org.json.JSONObject;



import com.nm.esign.R;
import com.nm.esign.adapter.GalleryDocumentAdapter;
import com.nm.esign.adapter.TemplateImageAdapter;
import com.nm.esign.check.Connectivity;
import com.nm.esign.entities.Entities;
import com.nm.esign.entities.TemplateFieldList;
import com.nm.esign.entities.ZoomLayout;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

import javax.net.ssl.HttpsURLConnection;

public class ViewTemplate extends AppCompatActivity /*implements View.OnTouchListener*/ {


    private String TAG = MainActivity.class.getSimpleName();

    private ArrayList<TemplateFieldList> templateFieldList;
    Map<Integer, ArrayList<TemplateFieldList> > myMap;
    android.support.v7.widget.AppCompatButton sendTemplate;
    private TemplateImageAdapter tAdapter;
    private RecyclerView recyclerView;
   // TextView tv_template_name;
   // android.support.v7.widget.AppCompatButton prevBtn,nextBtn;
    String templateId=null;
  public static  String templateIdTemp;
    public static String access_tokenTemp;
    String templateName=null;
    final Context context = this;

    //private EditText result;

    Entities entities=new Entities();
    Entities.Communicator communicator=entities.new Communicator();
    Entities.Server server=entities.new Server();
    Entities.LoginObjects loginObjects=entities.new LoginObjects();
    String access_token=null;
    String comm_urls;


    /*-------------------------------------------*//*
    private static final String TAG1 = "Touch";
    @SuppressWarnings("unused")
    private static final float MIN_ZOOM = 1f, MAX_ZOOM = 1f;

    Matrix matrix = new Matrix();
    Matrix savedMatrix = new Matrix();

    // The 3 states (events) which the user is trying to perform
    static final int NONE = 0;
    static final int DRAG = 1;
    static final int ZOOM = 2;
    int mode = NONE;

    // these PointF objects are used to record the point(s) the user is touching
    PointF start = new PointF();
    PointF mid = new PointF();
    float oldDist = 1f;
    *//*-------------------------------------------*/

    LinearLayout fl_zoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_view_template);

        //  prevBtn=(android.support.v7.widget.AppCompatButton)findViewById(R.id.btnDocumentPrev_temp);
        // nextBtn=(android.support.v7.widget.AppCompatButton)findViewById(R.id.btnDocumentNxt_temp);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view_template_img);
        loginObjects.USER = getApplicationContext().getSharedPreferences("USER", MODE_PRIVATE);
        sendTemplate = (android.support.v7.widget.AppCompatButton) findViewById(R.id.btnSendTemplateByViewImg);
        sendTemplate.setTransformationMethod(null);
        fl_zoom=(LinearLayout)findViewById(R.id.fl_zoom);


        ZoomLayout myZoomView = new ZoomLayout(ViewTemplate.this);
        //setContentView(myZoomView);
        fl_zoom.addView(myZoomView);
      /*  ZoomLayout myZoomView = new ZoomLayout(ViewTemplate.this);

        fl_zoom.addView(myZoomView);*/
       // tv_template_name=(TextView)findViewById(R.id.txt_img_document_nameFull_item);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        Intent iin = getIntent();
        Bundle b = iin.getExtras();
      //  this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (b != null) {
            templateId = (String) b.get("templateId");
            templateName=(String)b.get("templateName");
           // tv_template_name.setText(""+templateName);
          //  ViewTemplate.this.getActionBar().setTitle(""+tv_template_name);

            templateIdTemp=templateId;
        }
        setTitle(""+templateName);

        //getActionBar().setTitle(""+tv_template_name);
        Toast.makeText(getApplicationContext(), "templateId==" + templateId, Toast.LENGTH_LONG).show();
        loginObjects.ctx = ViewTemplate.this;
        if (new Connectivity(loginObjects.ctx).isNetworkAvailable()) {

            new ViewTemplate.GetAllTemplatesById().execute();


        } else {
            Toast.makeText(ViewTemplate.this, "Please Check Internet Connection", Toast.LENGTH_LONG).show();

        }

        recyclerView.addOnItemTouchListener(new GalleryDocumentAdapter.RecyclerTouchListener(getApplicationContext(), recyclerView, new GalleryDocumentAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                /*Bundle bundle = new Bundle();
                bundle.putSerializable("images", images);
                bundle.putInt("position", position);

                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                SlideshowDialogFragment newFragment = SlideshowDialogFragment.newInstance();
                newFragment.setArguments(bundle);
                newFragment.show(ft, "slideshow");*/
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
        sendTemplate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LayoutInflater li = LayoutInflater.from(context);
                View promptsView = li.inflate(R.layout.prompts, null);

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

                // set prompts.xml to alertdialog builder
                alertDialogBuilder.setView(promptsView);

                final EditText userInput = (EditText) promptsView.findViewById(R.id.editTextDialogUserInput);
                             userInput.setText(""+templateName);

                // set dialog message
                alertDialogBuilder
                        .setCancelable(false)
                        .setPositiveButton("OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,
                                                        int id) {
                                        // get user input and set it to result
                                        // edit text
                                       // result.setText(userInput.getText());
                                        Intent intent = new Intent(ViewTemplate.this, ViewRecipientInTemplateActivity.class);
                                        intent.putExtra("documentName",""+userInput.getText());
                                          startActivity(intent);
                                    }
                                })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,
                                                        int id) {
                                        dialog.cancel();
                                    }
                                });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();


               /* Intent intent = new Intent(ViewTemplate.this, ViewRecipientInTemplateActivity.class);
                startActivity(intent);*/
            }
        });



      /*  nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  fetchImages();
            }
        });

        prevBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  fetchImages();
            }
        });*/

    }

     /*------------------------------------------------------*/

   /* @Override
    public boolean onTouch(View v, MotionEvent event) {
        ImageView view = (ImageView) v;
        view.setScaleType(ImageView.ScaleType.MATRIX);
        float scale;

        dumpEvent(event);
        // Handle touch events here...

        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN: // first finger down only
                savedMatrix.set(matrix);
                start.set(event.getX(), event.getY());
                Log.d(TAG1, "mode=DRAG"); // write to LogCat
                mode = DRAG;
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:

                mode = NONE;
                Log.d(TAG1, "mode=NONE");
                break;

            case MotionEvent.ACTION_POINTER_DOWN:
                oldDist = spacing(event);
                Log.d(TAG1, "oldDist=" + oldDist);
                if (oldDist > 5f) {
                    savedMatrix.set(matrix);
                    midPoint(mid, event);
                    mode = ZOOM;
                    Log.d(TAG1, "mode=ZOOM");
                }
                break;

            case MotionEvent.ACTION_MOVE:

                if (mode == DRAG) {
                    matrix.set(savedMatrix);
                    matrix.postTranslate(event.getX() - start.x, event.getY()
                            - start.y); *//*
                                     * create the transformation in the matrix
                                     * of points
                                     *//*
                } else if (mode == ZOOM) {
                    // pinch zooming
                    float newDist = spacing(event);
                    Log.d(TAG1, "newDist=" + newDist);
                    if (newDist > 5f) {
                        matrix.set(savedMatrix);
                        scale = newDist / oldDist;
                    *//*
                     * setting the scaling of the matrix...if scale > 1 means
                     * zoom in...if scale < 1 means zoom out
                     *//*
                        matrix.postScale(scale, scale, mid.x, mid.y);
                    }
                }
                break;
        }

        view.setImageMatrix(matrix); // display the transformation on screen

        return true;
    }

    private float spacing(MotionEvent event) {
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return (float)Math.sqrt(x * x + y * y);
    }


    private void midPoint(PointF point, MotionEvent event) {
        float x = event.getX(0) + event.getX(1);
        float y = event.getY(0) + event.getY(1);
        point.set(x / 2, y / 2);
    }

    private void dumpEvent(MotionEvent event) {
        String names[] = { "DOWN", "UP", "MOVE", "CANCEL", "OUTSIDE",
                "POINTER_DOWN", "POINTER_UP", "7?", "8?", "9?" };
        StringBuilder sb = new StringBuilder();
        int action = event.getAction();
        int actionCode = action & MotionEvent.ACTION_MASK;
        sb.append("event ACTION_").append(names[actionCode]);

        if (actionCode == MotionEvent.ACTION_POINTER_DOWN
                || actionCode == MotionEvent.ACTION_POINTER_UP) {
            sb.append("(pid ").append(
                    action >> MotionEvent.ACTION_POINTER_ID_SHIFT);
            sb.append(")");
        }

        sb.append("[");
        for (int i = 0; i < event.getPointerCount(); i++) {
            sb.append("#").append(i);
            sb.append("(pid ").append(event.getPointerId(i));
            sb.append(")=").append((int) event.getX(i));
            sb.append(",").append((int) event.getY(i));
            if (i + 1 < event.getPointerCount())
                sb.append(";");
        }

        sb.append("]");
        Log.d("Touch Event", sb.toString());
    }

*//*------------------------------------------------------*//*


*/
    public class  GetAllTemplatesById extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() {
            try {
                communicator.isConnectTimeout = false;
                communicator.isError = false;
                communicator.isException = false;

                communicator.progressDialog = new ProgressDialog(loginObjects.ctx);
                communicator.progressDialog.setMessage("Loading........");
                communicator.progressDialog.setCancelable(false);
                communicator.progressDialog.show();

                access_token = loginObjects.USER.getString("access_token", "access_token");
                // access_token="c4c8f2ee034843bc9ff575922c0ccfa9";
                Log.i("access_token==", "" + access_token);
                Log.i("templateId==", "" + templateId);
                access_tokenTemp=access_token;



            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        protected Void doInBackground(Void... params) {
            try {
                communicator.urls = new URL(server.url + "/templates/mytemplate?templateId="+templateId);
                if (communicator.urls.getProtocol().toLowerCase().equals("https")) {
                    communicator.trustAllHosts();
                    HttpsURLConnection https = (HttpsURLConnection) communicator.urls.openConnection();
                    https.setHostnameVerifier(communicator.DO_NOT_VERIFY);
                    communicator.connection = https;
                } else {
                    communicator.connection = (HttpURLConnection) communicator.urls.openConnection();
                }

                communicator.connection.setConnectTimeout(communicator.TIME_OUT);
                communicator.connection.setReadTimeout(communicator.TIME_OUT);

                communicator.connection.setRequestMethod("GET");
                communicator.connection.setRequestProperty("Content-Length", communicator.param.getBytes().length + "");
                communicator.connection.setRequestProperty("Authorization", "Bearer " + access_token);

              Log.e("respose....", "respose code is: " + communicator.connection.getResponseCode());
                communicator.inStream = new Scanner(communicator.connection.getInputStream());
                communicator.response = "";
                while (communicator.inStream.hasNextLine()) {
                    communicator.response += (communicator.inStream.nextLine());
                }

                Log.e("response==" + communicator.urls, communicator.response + "");
                final JSONObject jObject = new JSONObject(communicator.response);
                String totalPage="";
                int totalPageCount=0;

                int mapKey=0;

              /*  if(jObject.has("template")) {
                    JSONObject jObjectTemplate=jObject.getJSONObject("template");
                    totalPage=jObjectTemplate.getString("totalPages");
                }
                System.out.println("totalPage##==" + totalPage);*/
                if (jObject.has("template")) {

                    JSONObject jObjectTemplate=jObject.getJSONObject("template");
                    totalPage=jObjectTemplate.getString("totalPages");
                    Log.e("##totalPage=", "totalPage is: " + totalPage);
                    if(totalPage!=null || totalPage!="")
                    {
                        totalPageCount=Integer.parseInt(totalPage);
                        Log.e("##totalPageCount=", "totalPageCount is: " + totalPage);
                    }
                    myMap = new HashMap<Integer, ArrayList<TemplateFieldList>>();
                    Log.e("respose1....", "respose1 code is: " + communicator.connection.getResponseCode());

                    JSONArray resultJsonArr = jObject.getJSONArray("allfields");
                    Log.e("respose0....", "respose0 code is: " + resultJsonArr);
                    String documentPageNumber="1";
                    for (int i = 0; i < resultJsonArr.length(); i++) {

                        TemplateFieldList templateList = new TemplateFieldList();


                        JSONObject resultInstanceJson = resultJsonArr.getJSONObject(i);
                        templateList.setAllfields_coordinateXRatio(resultInstanceJson.getString("coordinateXRatio"));
                        templateList.setAllfields_coordinateYRatio(resultInstanceJson.getString("coordinateYRatio"));
                        templateList.setAllfields_elementHeightRatio(resultInstanceJson.getString("elementHeightRatio"));
                        templateList.setAllfields_elementWidthRatio(resultInstanceJson.getString("elementWidthRatio"));
                        templateList.setAllfields_TagId(resultInstanceJson.getString("fieldTagId"));
                        templateList.setAllfields_documentPageNumber(resultInstanceJson.getString("documentPageNumber"));
                        templateList.setAllfields_fieldType(resultInstanceJson.getString("fieldType"));
                        templateList.setTemplateName(""+templateName);
                        documentPageNumber=resultInstanceJson.getString("documentPageNumber");

                        Log.e("documentPageNumber==", "documentPageNumber="+documentPageNumber);

                        if(myMap.containsKey(Integer.parseInt(documentPageNumber)))
                        {
                          ArrayList templateImageList =myMap.get(Integer.parseInt(documentPageNumber));
                            templateImageList.add(templateList);
                        }
                        else
                        {
                                ArrayList templateImageList = new ArrayList<>();
                                templateImageList.add(templateList);
                                myMap.put(Integer.parseInt(documentPageNumber), templateImageList);
                               // myMap.put(""+mapKey, templateImageList);

                            }


                    }

                    for(int temp=0;temp<totalPageCount;temp++)
                    {
                        mapKey=mapKey+1;

                        if(!myMap.containsKey(mapKey)){
                            ArrayList templateImageList = new ArrayList<>();
                            myMap.put( mapKey, templateImageList);
                        }
                    }


                } else {

                    Log.e("no template==", "no template");
                }
                Log.e(" myMap==", "myMap="+myMap.get(0));


            } catch (Exception ex) {
                communicator.isException = true;
                ex.printStackTrace();

            }
            return null;
        }

        protected void onPostExecute(Void result) {
            communicator.progressDialog.dismiss();
           // Log.e(" size==", "size="+templateFieldList.size());
            /*for (TemplateFieldList templateList : templateFieldList) {
                myMap.put(templateList.getAllfields_documentPageNumber(), templateList);
            }*/
            Log.e(" myMap==", "myMap="+myMap.get(0));

           /* sort hash map order of key*/

          //  Map<Integer,  ArrayList<TemplateFieldList>> map = new TreeMap<Integer,  ArrayList<TemplateFieldList>>(myMap);

           /* Map<Integer,  ArrayList<TemplateFieldList>> treeMap = new TreeMap<Integer,  ArrayList<TemplateFieldList>>(
                    new Comparator<Integer>() {

                        @Override
                        public int compare(Integer o1, Integer o2) {
                            return o2.compareTo(o1);
                        }

                    });*/

          //  map.putAll(myMap);


           /* ...............................................................................*/
            TreeMap<Integer,  ArrayList<TemplateFieldList>> treeMap = new TreeMap<Integer,  ArrayList<TemplateFieldList>>(myMap);
            tAdapter = new TemplateImageAdapter(ViewTemplate.this, treeMap);
            RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getApplicationContext(), 1);
            recyclerView.setLayoutManager(mLayoutManager);
            recyclerView.setItemAnimator(new DefaultItemAnimator());
            recyclerView.setAdapter(tAdapter);


        }
    }
}
